## Batch deployment

* Turn the notebook for training a model into a notebook for applying the model
* Turn the notebook into a script 
* Clean it and parametrize
